//
//  main.swift
//  Swift_Features
//
//  Created by Emmanuel Almonte on 5/27/21.
//  Copyright © 2021 Emmanuel Almonte. All rights reserved.
//

import Foundation


var num1, num2, num3: String

var allUsrNum = [String]()

print("Enter a number: ")
num1 = readLine() ?? ""
var intNum1 = Double(num1) ?? 0
allUsrNum.append(num1)

print("Enter a number")
num2 = readLine() ?? ""
var intNum2 = Double(num2) ?? 0
allUsrNum.append(num2)

print("Enter a number")
num3 = readLine() ?? ""
var intNum3 = Double(num3) ?? 0
allUsrNum.append(num3)

var amtOfNums: Double = Double(allUsrNum.count)


var avgOfNums = (intNum1 + intNum2 + intNum3)/(amtOfNums)

print("The mean was \(avgOfNums)")

print("Enter another number: ")
var anNum = readLine() ?? ""
var intanNum = Double(anNum) ?? 0.0

print("The mean plus \(intanNum) is ", avgOfNums+intanNum)

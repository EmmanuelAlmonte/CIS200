#Emmanuel Almonte Community College of Philadelphia
#Course CIS 200
#Instructor Laurence Liss

userNum1 = float(input("Enter a number: "))
userNum2 = float(input("Enter a number: "))
userNum3 = float(input("Enter a number: "))

alluserNums = []

alluserNums.append(userNum1)
alluserNums.append(userNum2)
alluserNums.append(userNum3)

avg = (userNum1 + userNum2 + userNum3)/ len(alluserNums)

print("The mean was: ", avg)

lastNum = float(input("Enter a number: "))

print("The mean plus ", lastNum, "is",  lastNum + avg )
